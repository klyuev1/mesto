// Объявление всех переменных
// Объявление кнопок добавить и редактировать в профиле
export const cardAdd = document.querySelector('.profile__button-add');
export const profileEdit = document.querySelector('.profile__button-edit');
// Объявление темплейта и его родительского элемента
export const inputPopupName = document.querySelector('.popup__input[name=name]');
export const inputPopupOccupation = document.querySelector('.popup__input[name=occupation]');
// Объявление инпутов и формы для карточек
export const formElementCard = document.querySelector('.popup__form[name=card]');
// Формы профиля и карточки форм
export const FormElementProfile = document.querySelector('.popup__form[name=profile]');
export const FormElementCard = document.querySelector('.popup__form[name=card]');
export const buttonOpenUpdteAvatarForm = document.querySelector('.profile__avatar-button');
export const FormElementAvatar = document.querySelector('.popup__form[name=update]');