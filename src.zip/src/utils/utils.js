export function renderLoading(submitButton,text) {
  submitButton.textContent = text;
}